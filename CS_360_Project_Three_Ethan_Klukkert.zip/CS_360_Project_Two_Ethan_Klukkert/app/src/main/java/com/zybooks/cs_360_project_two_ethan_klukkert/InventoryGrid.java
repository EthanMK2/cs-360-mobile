package com.zybooks.cs_360_project_two_ethan_klukkert;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.FrameLayout;

public class InventoryGrid extends AppCompatActivity {

    // class for each inventory item
    public class InventoryItem {
        private String name;
        private int quantity;

        public InventoryItem(String newName, int newQuantity) {
            name = newName;
            quantity = newQuantity;
        }
    }

    // Inventory Grid class

    private InventoryItem[] inventory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_grid);

        // demo data

        InventoryItem item1 = new InventoryItem("Bracelet", 5);
        InventoryItem item2 = new InventoryItem("T-shirt", 27);
        InventoryItem item3 = new InventoryItem("Coffee Mug", 14);
        InventoryItem item4 = new InventoryItem("Shoes", 3);
        InventoryItem item5 = new InventoryItem("Watch", 9);
        InventoryItem[] demoData = {item1, item2, item3, item4, item5};


        FrameLayout.LayoutParams frameLayoutParams = new FrameLayout.LayoutParams(gravity="fill_horizontal");
        for (int i = 0; i < demoData.length; i++) {

        }
    }
}