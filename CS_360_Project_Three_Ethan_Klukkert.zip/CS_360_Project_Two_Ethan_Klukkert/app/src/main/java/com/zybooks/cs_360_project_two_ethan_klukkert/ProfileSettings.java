package com.zybooks.cs_360_project_two_ethan_klukkert;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ProfileSettings extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_settings);
    }
}